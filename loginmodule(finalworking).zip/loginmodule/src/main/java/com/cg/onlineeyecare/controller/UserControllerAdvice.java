package com.cg.onlineeyecare.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cg.onlineeyecare.exceptions.PasswordNotMatchException;
import com.cg.onlineeyecare.exceptions.UserNotFoundException;
/********************************************************
 *   @author              P.Saiteja reddy
 *   Description          It is a controller advice class that handles the exception occurs at 
 *                        UserNotFoundException class
 *   Version              1.0
 *   created date         24-03-2021
 */
@RestControllerAdvice
public class UserControllerAdvice {
/*******************************************************
 * Method                UserException
 * Description           It is used to return the exception message and its HTTP status
 * @response entity      It returns the exception message and its HTTP status. 
 * @param exception      It is parent class of exception
 * created by:           P.saiteja reddy
 * created date:         24-03-2021
 */
	@ExceptionHandler({UserNotFoundException.class,PasswordNotMatchException.class})
	public String onlineeyecare(Exception e)
	{
		return e.getMessage();
	}
}

