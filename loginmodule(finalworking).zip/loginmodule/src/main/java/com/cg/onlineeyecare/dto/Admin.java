package com.cg.onlineeyecare.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
/*************************************************************************
 * @author               P.saiteja reddy
 * Description           It is a entity class that provides the details of the admin
 * Version               1.0
 * created date          24-03-2021    
 ***************************************************************************/
@Entity
public class Admin {
	@Id
	private int adminId;
	private String adminUsername;
	private String adminPassword;
	/***************************************************************************
	 * Method            getAdminId        
	 * Description       It is used to get the test Id by getter method. 
	 * @return integer   It returns admin Id
	 * created by        P.saiteja reddy
	 * created date      24-03-2021
	 */
	public int getAdminId() {
		return adminId;
	}
	/*******************************************************************************
	 * Method             setAdminId
	 * Description        It is used to set the admin Id by setter method.
	 * @param adminId     admin's  Id
	 * created by         P.saiteja reddy
	 * created date       24-03-2021
	 */
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	/*******************************************************************************
	 * Method             getAdminusername
	 * Description         It is used to get the admin username by getter method 
	 * @return string      It return admin username
	 * created by          P.saiteja reddy
	 * Created date        24-03-2021	 
	 * ********************************************************************************/
	public String getAdminUsername() {
		return adminUsername;
	}
	/*******************************************************************************
	 * method                      setAdminusername
	 * Description                 It is used to set the admin username by setter method.
	 * @param adminUsername        admin's  username
	 * created by                  P.saiteja reddy
	 * created date                24-03-2021
	 *********************************************************************************/
	public void setAdminUsername(String adminUsername) {
		this.adminUsername = adminUsername;
	}
	/**********************************************************************************
	 * Method                   getAdminPassword
	 * Description              it is used to get the admin password by getter method
	 * @return string           It return admin password
	 * created by                p.saiteja reddy
	 * created date              24-03-2021
	 **********************************************************************************/
	public String getAdminPassword() {
		return adminPassword;
	}
	/********************************************************************************
	 * Method                   setadminPassword
	 * Description              It is used to set the admin password by setter method
	 * @param adminPassword     admin's password
	 * created by               P.saiteja reddy
	 * created date             24-03-2021
	 */
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
		/************************************************************************************
		 * Method:                          admin
	     *Description:                      It is used to initialize the empty constructor.
	     *Created By                      - p.saiteja reddy
	     *Created Date                    - 24-MARCH-2021  */
	public Admin() {
		super();
	}
	/************************************************************************************
	 * Method:                               admin
     *Description:                           It is used to initialize the parameterized constructor.
     *@param adminId:                        test's Id. 
     *@param adminUsername:                  test's Name. 
     *@param adminPassword:                  test's Type.  
     *Created By                            - p.saitejareddy
     *Created Date                          - 24-MARCH-2021                           
	 
	 ************************************************************************************/
	public Admin(int adminId, String adminUsername, String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminUsername = adminUsername;
		this.adminPassword = adminPassword;
	}	
}


