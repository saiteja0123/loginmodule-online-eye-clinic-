package com.cg.onlineeyecare.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "User_Table1")
public class User {
	@Id
	private String userName;
	private String password;
	private String role;
	/***************************************************************
	 * Method                    getuserName
	 * Description               It is used to get the userName by getter method
	 * @return integer           it returns userName
	 * created by                P.saiteja reddy
	 * created date              24-03-2021
	 *******************************************************************/	
	
	public String getUserName() {
		return userName;
	}
	/***************************************************************
	 * Method                    setUserName
	 * Description               It is used to get the userName by setter method
	 * @return integer           it returns userName
	 * created by                P.saiteja reddy
	 * created date              24-03-2021
	 *******************************************************************/	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/***************************************************************
	 * Method                    getPassword
	 * Description               It is used to get the userPassword by getter method
	 * @return integer           it returns userPassword
	 * created by                P.saiteja reddy
	 * created date              24-03-2021
	 *******************************************************************/	
	public String getPassword() {
		return password;
	}
	/***************************************************************
	 * Method                    setPassword
	 * Description               It is used to set the userName by setter method
	 * @return integer           it returns userPassword
	 * created by                P.saiteja reddy
	 * created date              24-03-2021
	 *******************************************************************/	
	public void setPassword(String password) {
		this.password = password;
	}
	/***************************************************************
	 * Method                    getRole
	 * Description               It is used to get the userRole by getter method
	 * @return integer           it returns userRole
	 * created by                P.saiteja reddy
	 * created date              24-03-2021
	 *******************************************************************/	
	public String getRole() {
		return role;
	}
	/***************************************************************
	 * Method                    setRole
	 * Description               It is used to set the userRole by setter method
	 * @return integer           it returns userRole
	 * created by                P.saiteja reddy
	 * created date              24-03-2021
	 *******************************************************************/	
	public void setRole(String role) {
		this.role = role;
	}
	/************************************************************************************
	 * Method:                          User
     *Description:                      It is used to initialize the empty constructor.
     *Created By                      - p.saiteja reddy
     *Created Date                    - 24-MARCH-2021  */
	public User() {
		super();
	}
	/************************************************************************************
	 * Method:                                 User
     *Description:                             It is used to initialize the parameterized constructor.
     *@param username:                         user name 
     *@param password:                         user password 
     *@param role:                             user role 
     *Created By                            -  p.saitejareddy
     *Created Date                          -  24-MARCH-2021                           
	 
	 ************************************************************************************/
	public User(String userName, String password, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	

}
