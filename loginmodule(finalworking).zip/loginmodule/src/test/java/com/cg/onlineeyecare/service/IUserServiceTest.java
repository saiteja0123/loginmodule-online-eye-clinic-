package com.cg.onlineeyecare.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;
import com.cg.onlineeyecare.dto.User;
import com.cg.onlineeyecare.exceptions.PasswordNotMatchException;
import com.cg.onlineeyecare.exceptions.UserNotFoundException;

@SpringBootTest
public class IUserServiceTest  {
	@Autowired
	private IUserService userService;
	User user= new User("saiteja@123","manojan456","Doctor");
	User user1= new User("saiteja","manojan456","Doctor");
	User user2= new User("manojan321","manojan456","eyespecialist");

	
	
	
	/***********************************************************
	 * Method                                         testchangePassword
	 * Description                                    It is used to test whether the passowrd is changed or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * @throws PasswordNotMatchException              It is raises due to invalid password
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	@Test
	void testchangePassword() throws UserNotFoundException, PasswordNotMatchException {
	
		assertEquals("manojan456",userService.changePassword("manojan456",user).getPassword());
	}
	

	/***********************************************************
	 * Method                                         testSignIn1
	 * Description                                    It is used to test whether user is signed in or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * Created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                  */
	
	
	@Test
	void testSignIn1() throws UserNotFoundException {
		assertTrue(userService.signIn(user1));
	}
	/***********************************************************
	 * Method                                         testSignOut2
	 * Description                                    It is used to test whether the user is signed out or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	
	
	
	@Test
	void testsignOut2() throws UserNotFoundException {
		assertTrue(userService.signOut(user2));
	}
	
	/***********************************************************
	 * Method                                         testchangePassword1
	 * Description                                    It is used to test whether the passoword is changed or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * @throws PasswordNotMatchException              It is raises due to invalid password
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                  */
	@Test
	void testchangePassword1() throws UserNotFoundException, PasswordNotMatchException {
	
		assertEquals("manojan456",userService.changePassword("manojan456",user2).getPassword());
	}

	
	
	
	
	
		
	
	


}
